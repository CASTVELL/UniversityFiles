/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author estudiantes
 */
public class Asignatura {
    private String[] preRequisitos= new String[5];

    public String[] getPreRequisitos() {
        return preRequisitos;
    }

    public void setPreRequisitos(String[] preRequisitos) {
        this.preRequisitos = preRequisitos;
    }
    
    
}
