/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CareersTesting;

/**
 *
 * @author Luis Miguel Castellanos 20162020084
 */
public class AbstractC {

    private String name;
    private String avaibleShedule;

    public String getAvaibleShedule() {
        return avaibleShedule;
    }

    public String getName() {
        return name;
    }

    public void setAvaibleShedule(String avaibleShedule) {
        this.avaibleShedule = avaibleShedule;
    }

    public void setName(String name) {
        this.name = name;
    }

}
