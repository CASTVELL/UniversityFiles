/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Careers;

import CareersTesting.AbstractC;

/**
 *
 * @author USUARIO
 */
public class Derecho extends AbstractC {

    public Derecho() {
        setName("Derecho");
        setAvaibleShedule("Diurno");
    }
    
}
