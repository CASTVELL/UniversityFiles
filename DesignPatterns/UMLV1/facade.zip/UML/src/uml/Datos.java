package UML;

import java.util.ArrayList;
import java.util.List;

public class Datos {

    String NombreClase;
    List<String> Atributos = new ArrayList<String>();
    List<String> Metodos = new ArrayList<String>();
    List<String> Relacion = new ArrayList<String>();
    String TipoClase;
    List<String> TipoAtributos = new ArrayList<String>();
    List<String> VisibilidadAtributos = new ArrayList<String>();
    List<String> TipoMetodos = new ArrayList<String>();
    List<String> VisibilidadMetodos = new ArrayList<String>();
    int CoordenadaX = 10;
    int CoordenadaY = 100;
    int CantidadAtributos = 0;
    int CantidadMetodos = 0;
}
