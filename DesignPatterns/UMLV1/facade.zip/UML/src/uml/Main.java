package UML;

public class Main {
	public static void main (String arg[]) {
		Ventana1 Iniciar = new Ventana1();
		Iniciar.setVisible(true);
		//Iniciar.setResizable(false);
	}
        
}
